import mysql.connector

con=mysql.connector.connect(host='budvhh9uzhozsc076t2e-mysql.services.clever-cloud.com',user='uprgwqcd2h6boxrf',password='a6PPDReaqBtnt0iqYSQv',database='budvhh9uzhozsc076t2e')
curs=con.cursor()


author=input("Enter the name of Author : ")
publication=input("Enter the name of Publication : ")

curs.execute("select * from books where author='%s' and publication='%s';" %(author,publication))
rec=curs.fetchone()


try:
    print("-------------------------------------")
    print("The bookname is :- %s" %rec[1])
    print("-------------------------------------")
except:
    print("book not found")

con.close() 