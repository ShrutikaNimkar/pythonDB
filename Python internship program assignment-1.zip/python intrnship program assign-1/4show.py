
import mysql.connector

con=mysql.connector.connect(host='budvhh9uzhozsc076t2e-mysql.services.clever-cloud.com',user='uprgwqcd2h6boxrf',password='a6PPDReaqBtnt0iqYSQv',database='budvhh9uzhozsc076t2e')
curs=con.cursor()

curs.execute("select * from books")
all=curs.fetchall()

for one in all:
    
    print("book-code : %s" %one[0])
    print("book-Name : %s" %one[1])
    print("Category : %s" %one[2])
    print("Author : %s" %one[3])
    print("Publication : %s" %one[4])
    print("Edition : %d" %one[5])
    print("Price : %d" %one[6])
    print('-------------------------------')

con.close()    