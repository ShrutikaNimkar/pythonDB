import mysql.connector

con=mysql.connector.connect(host='budvhh9uzhozsc076t2e-mysql.services.clever-cloud.com',user='uprgwqcd2h6boxrf',password='a6PPDReaqBtnt0iqYSQv',database='budvhh9uzhozsc076t2e')
curs=con.cursor()

b=input("Enter the Bookcode : ")

curs.execute("select bookcode from books where bookcode='%s';"%(b))
one=curs.fetchone()
try:
    if b in one:
        r=input("Write the Review : ")
        curs.execute("update books set review='%s' where bookcode='%s';"%(r,b))
        con.commit()
        print("Review will be Submmited")

except:
 print("Book is not present....")  
