import mysql.connector

con=mysql.connector.connect(host='budvhh9uzhozsc076t2e-mysql.services.clever-cloud.com',user='uprgwqcd2h6boxrf',password='a6PPDReaqBtnt0iqYSQv',database='budvhh9uzhozsc076t2e')
curs=con.cursor()
bookcode=input("Enter the Book Code : ")
bookname=input("Enter the Book Name : ")
category=input("Enter the Book Category : ")
author=input("Enter the Book Author : ")
publication=input("Enter the Book Publication : ")
edition=int(input("Enter the Book Edition : "))
price=int(input("Enter the Book Price : "))
r=input("enter a review : ")
try:

    curs.execute("insert into books values('%s','%s','%s','%s','%s',%d,%d,'%s')"  %(bookcode,bookname,category,author,publication,edition,price,r))
    con.commit()
    print("New Book Added Successfully..")
except:
     print("New Book Addition failed..")
con.close()
