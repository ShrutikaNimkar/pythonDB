import mysql.connector

con=mysql.connector.connect(host='budvhh9uzhozsc076t2e-mysql.services.clever-cloud.com',user='uprgwqcd2h6boxrf',password='a6PPDReaqBtnt0iqYSQv',database='budvhh9uzhozsc076t2e')
curs=con.cursor()
category=input("Enter the category : ")
curs.execute("select * from books where category='%s'" %category)
all=curs.fetchall()
print("List of book with category %s"%category+" is ")
for one in all:
    
    print(" ----> %s" %one[1])
    

con.close()    
 