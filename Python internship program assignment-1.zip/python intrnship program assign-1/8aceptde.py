import mysql.connector
con=mysql.connector.connect(host='budvhh9uzhozsc076t2e-mysql.services.clever-cloud.com',user='uprgwqcd2h6boxrf',password='a6PPDReaqBtnt0iqYSQv',database='budvhh9uzhozsc076t2e')
curs=con.cursor()

s=input("Enter a book-code do you want to search : ")

curs.execute("select bookcode,bookname,category,author,publication,edition,price from books where bookcode='%s'" %s)
rec=curs.fetchone()


try:

    print("The information of Book-Code %s" %rec[0]+" is ")
    
    print("Book-Name     : %s" %rec[1])
    print("Category      : %s" %rec[2])
    print("Author        : %s" %rec[3])
    print("Publication   : %s" %rec[4])
    print("Edition       : %s" %rec[5])
    print("Price         : %s" %rec[6])
    print("----------------------------------")  
    curs.execute("select bookcode from books where bookcode='%s';"%s)
    one=curs.fetchone()    
    if s in one:
      print("write yes or no")
      d=input("Do you want to delete this book?\n")
      if d=='yes':
       
        curs.execute("DELETE FROM books where bookcode='%s'" %s)
        con.commit()
        print("book is deleted")    
      else:
         ("ok...that's fine!")
except:
    print("book not found....")

con.close() 