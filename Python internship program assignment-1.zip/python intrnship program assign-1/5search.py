import mysql.connector

con=mysql.connector.connect(host='budvhh9uzhozsc076t2e-mysql.services.clever-cloud.com',user='uprgwqcd2h6boxrf',password='a6PPDReaqBtnt0iqYSQv',database='budvhh9uzhozsc076t2e')
curs=con.cursor()

s=input("Enter the Book Code : ")

curs.execute("select bookcode,bookname,category,author,publication,edition,price from books where bookcode='%s'" %s)
rec=curs.fetchone()


try:
    
    print("Book-Name     : %s" %rec[1])
    print("Category      : %s" %rec[2])
    print("Author        : %s" %rec[3])
    print("Publication   : %s" %rec[4])
    print("Edition       : %d" %rec[5])
    print("Price         : %d" %rec[6])
    
except:
    print("book not found")

con.close() 