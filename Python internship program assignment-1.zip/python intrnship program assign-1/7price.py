import mysql.connector

con=mysql.connector.connect(host='budvhh9uzhozsc076t2e-mysql.services.clever-cloud.com',user='uprgwqcd2h6boxrf',password='a6PPDReaqBtnt0iqYSQv',database='budvhh9uzhozsc076t2e')
curs=con.cursor()

bcode=input("Enter a bookcode : ")


curs.execute("select bookcode from books where bookcode='%s';"%(bcode))
one=curs.fetchone()
try:
        if bcode in one:
            price=int(input("set the price do you want to update : "))
            curs.execute("update books set price='%d' where bookcode='%s';"%(price,bcode))
            con.commit()

            print("Price Updated")
            print("price of bookcode %s is now %d "%(bcode,price))
      
except:
        print("Book Addition failed")  
